# bullet-objects
URDF, MTL, OBJ, and image files for objects used in pybullet environments.

This repository contains object-relevant files available for loading into pybullet environments. It is intended to be loaded as a submodule under bullet-manipulation/roboverse/envs/assets, to replace the objects folder.
